public class Test 
{
	public static void main(String []args)
	{
		Triangle o1 = new Triangle(10,10,10);
		o1.showInfo();
		o1.testTriangle();

		Triangle o2 = new Triangle(5,9,5);
		o2.showInfo();
		o2.testTriangle();

		Triangle o3 = new Triangle(4,3,8);
		o3.showInfo();
		o3.testTriangle();

	}
}