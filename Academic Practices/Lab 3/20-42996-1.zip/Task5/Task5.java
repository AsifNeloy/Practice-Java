import java.util.Scanner;
import java.util.Arrays;
public class Task5{ 
public static void main(String[] args){ 
Scanner sc = new Scanner(System.in);
System.out.print("Enter a String : ");
String st = sc.nextLine();
StringBuffer sb2 = new StringBuffer(st);

      System.out.println("Using StringBuffer "+sb2);
}}