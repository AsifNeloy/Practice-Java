import java.util.Scanner;
public class Task3{  
public static void main(String args[]){  
Scanner sc = new Scanner(System.in);
String s1="Hello "; 
System.out.print("Enter your name : ");
String st = sc.nextLine();
s1=s1.concat(st);  
System.out.println(s1);  
}}  