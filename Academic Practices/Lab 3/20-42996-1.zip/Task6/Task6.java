import java.util.Scanner;

public class Task6{ 
public static void main(String[] args){ 
Scanner sc = new Scanner(System.in);
System.out.println("Enter your email address : ");
String st = sc.nextLine();
for(int i=0;i<st.length();i++){
	char c = st.charAt(i);
	if(c == '@'){
		
		{System.out.println("Correct email");}}
		
	
}
}}